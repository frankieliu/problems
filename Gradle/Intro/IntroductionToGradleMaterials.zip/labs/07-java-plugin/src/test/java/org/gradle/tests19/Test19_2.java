package org.gradle.tests19;

import org.junit.Test;

public class Test19_2 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}