package org.gradle.tests2;

import org.junit.Test;

public class Test2_7 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}