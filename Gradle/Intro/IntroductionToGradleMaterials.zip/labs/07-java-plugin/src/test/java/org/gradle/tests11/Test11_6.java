package org.gradle.tests11;

import org.junit.Test;

public class Test11_6 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}