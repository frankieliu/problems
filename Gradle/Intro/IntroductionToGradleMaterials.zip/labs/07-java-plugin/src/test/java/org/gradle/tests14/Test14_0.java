package org.gradle.tests14;

import org.junit.Test;

public class Test14_0 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}