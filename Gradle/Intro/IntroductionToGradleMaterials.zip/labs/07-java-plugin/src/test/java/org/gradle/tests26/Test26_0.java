package org.gradle.tests26;

import org.junit.Test;

public class Test26_0 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}