package org.gradle.tests17;

import org.junit.Test;

public class Test17_2 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}