package org.gradle.tests22;

import org.junit.Test;

public class Test22_0 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}