package org.gradle.tests9;

import org.junit.Test;

public class Test9_0 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}