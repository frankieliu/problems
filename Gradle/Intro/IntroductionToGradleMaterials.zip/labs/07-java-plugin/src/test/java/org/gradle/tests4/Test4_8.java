package org.gradle.tests4;

import org.junit.Test;

public class Test4_8 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}