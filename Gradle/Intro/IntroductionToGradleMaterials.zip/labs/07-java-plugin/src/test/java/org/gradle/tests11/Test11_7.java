package org.gradle.tests11;

import org.junit.Test;

public class Test11_7 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}