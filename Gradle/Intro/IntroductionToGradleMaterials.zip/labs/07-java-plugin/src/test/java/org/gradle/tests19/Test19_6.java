package org.gradle.tests19;

import org.junit.Test;

public class Test19_6 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}