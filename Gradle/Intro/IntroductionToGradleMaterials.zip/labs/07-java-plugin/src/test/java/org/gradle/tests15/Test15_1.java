package org.gradle.tests15;

import org.junit.Test;

public class Test15_1 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}